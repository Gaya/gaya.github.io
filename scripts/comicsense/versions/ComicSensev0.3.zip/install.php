<?php
//Process information in session
session_start(); 
header("Cache-control: private"); //IE 6 Fix 

include('includes/header.php');

echo"<div class=\"pageheader\">Comic Sense - Install!</div>";

if($_POST['post'] && $_POST['username1'] && $_POST['password1'] && $_POST['email1'] && $_POST['address1']){
	include('includes/connect.php');

	//Create tables:
	$query = "CREATE TABLE ".$prefix."comic (
	  episodenr int(11) NOT NULL default '0',
	  `date` datetime default '0000-00-00 00:00:00',
	  title varchar(255) NOT NULL default '',
	  PRIMARY KEY  (episodenr)
	) ENGINE=MyISAM DEFAULT CHARSET=latin1;";
	echo "<div>Creating table comic... ";
	$q = mysql_query($query) or die ("Failed!</div>");
	echo "Succeeded!</div>";
			
	$query = "CREATE TABLE ".$prefix."comments (
	  episodenr int(11) NOT NULL default '0',
	  commentnr int(11) NOT NULL auto_increment,
	  `name` varchar(50) NOT NULL default '',
	  email varchar(255) NOT NULL default '',
	  website varchar(255) NOT NULL default '',
	  `comment` text NOT NULL,
	  ip varchar(15) NOT NULL default '',
	  `date` datetime NOT NULL,
	  PRIMARY KEY  (episodenr,commentnr)
	) ENGINE=MyISAM DEFAULT CHARSET=latin1;";
	echo "<div>Creating table comments... ";
	$q = mysql_query($query) or die ("Failed!</div>");
	echo "Succeeded!</div>";

	$query = "CREATE TABLE ".$prefix."pa (
	  panr int(11) NOT NULL auto_increment,
	  `date` datetime NOT NULL,
	  title varchar(255) NOT NULL,
	  `type` varchar(255) NOT NULL,
	  `name` varchar(255) NOT NULL,
	  message text NOT NULL,
	  PRIMARY KEY  (panr)
	) ENGINE=MyISAM DEFAULT CHARSET=latin1;";
	echo "<div>Creating table pa... ";
	$q = mysql_query($query) or die ("Failed!</div>");
	echo "Succeeded!</div>";

	$query = "CREATE TABLE ".$prefix."stats (
	  episodenr int(11) NOT NULL default '0',
	  ip varchar(15) NOT NULL default '',
	  count int(11) NOT NULL default '0',
	  PRIMARY KEY  (episodenr,ip)
	) ENGINE=MyISAM DEFAULT CHARSET=latin1;";
	echo "<div>Creating table stats... ";
	$q = mysql_query($query) or die ("Failed!</div>");
	echo "Succeeded!</div>";

	$query = "CREATE TABLE ".$prefix."users (
	  username varchar(255) NOT NULL,
	  `password` varchar(32) NOT NULL,
	  email varchar(255) NOT NULL
	) ENGINE=MyISAM DEFAULT CHARSET=latin1;";
	echo "<div>Creating table users... ";
	$q = mysql_query($query) or die ("Failed!</div>");
	echo "Succeeded!</div>";
			
	$query="INSERT INTO " . $prefix . "users (username, password, email) VALUES ('" . $_POST['username1'] . "', '" . md5($_POST['password1']) . "', '" . $_POST['email1'] . "')";
	mysql_query($query);
	echo"<div class=\"message\">Tables created and the admin has been created. You can now use comic system... please delete this file from your ftp for safety reasons.</div>";
	
	mail("gayakessler@planet.nl", "New install!",
"Comic Sense has a new user!\n

Email: " . $_POST['email1'] . "\n
Address: " . $_POST['address1'] . "\n
Real: " . $_SERVER['PHP_SELF'] . "
", "From: ComicSense");
	
} else {

echo"
	<div>
	<p>
		Thank you for using Comic Sense, the php comichosting script by Gaya Kessler.
	</p>
	<p>
		Make sure you edited the includes/connect.php file to your database connection prefs. Without the right settings, the installation will fail. The tables will be created at the next step.
	</p>
	<p>
		If everything is correct... we will now proceed with the installation.<br />
		Please, fill in the account information for the ADMIN of this page:
	</p>
	</div>
		<form method=\"post\" action=\"" . $_SERVER['PHP_SELF'] . "\">
			<div class=\"commentform\">
				<input type=\"hidden\" name=\"post\" value=\"true\" />";
			
			if ($_POST['post'] && !$_POST['username1']) {
				echo"<div class=\"error\">Please make sure you enter a username</div>";
			}
			
			if ($_POST['post'] && !$_POST['password1']) {
				echo"<div class=\"error\">Set a password</div>";
			}
			
			if ($_POST['post'] && !$_POST['email1']) {
				echo"<div class=\"error\">Enter the user's e-mail address</div>";
			}
			
			if ($_POST['post'] && !$_POST['address1']) {
				echo"<div class=\"error\">Enter the address the comic is going to be on</div>";
			}
				
			echo"<table>
					<tr>
						<td>Username:</td><td><input type=\"text\" style=\"width: 200px;\" class=\"inputform\" value=\"" . $_POST['username1'] . "\" name=\"username1\" size=\"20\" />
						</td>
					</tr>
					<tr>
						<td>Password:</td><td><input type=\"password\" style=\"width: 200px;\" class=\"inputform\" value=\"" . $_POST['password1'] . "\" name=\"password1\" size=\"20\" /> (will be hashed in md5)</td>
					</tr>
					<tr>
						<td>E-mail address:</td><td><input type=\"text\" style=\"width: 200px;\" class=\"inputform\" value=\"" . $_POST['email1'] . "\" name=\"email1\" size=\"20\" /></td>
					</tr>
					<tr>
						<td>Comic site address:</td><td><input type=\"text\" style=\"width: 200px;\" class=\"inputform\" value=\"" . $_POST['address1'] . "\" name=\"address1\" size=\"20\" /></td>
					</tr>
					<tr>
						<td colspan=\"2\" class=\"buttoncell\">
							<input type=\"submit\" class=\"button\" value=\"Create User\" />
						</td>
					</tr>
				</table>
			</div>
		</form>
		";
}
include('includes/footer.php');

?>
