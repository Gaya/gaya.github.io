<?php
echo"<div class=\"buttons\">";

//check if episode number is not too high
if ($epi > $latestEpisode['0']) {
	$epi = $latestEpisode['0'];
}

if ($epi != 1 && $latestEpisode['0'] != 1 ) {

	echo"<a href=\"?epi=1\"><img src=\"css/$cssname/images/first.gif\" alt=\"Go to first comic\" /></a> ";

	if ($epi){
		echo"<a href=\"?epi=" . ($epi - 1) . "\"><img src=\"css/$cssname/images/back.gif\" alt=\"Go back one comic\" /></a>";
	} else {
		echo"<a href=\"?epi=" . ($latestEpisode['0'] - 1) . "\"><img src=\"css/$cssname/images/back.gif\" alt=\"Go back one comic\" /></a>";
	}

} else {
	
	echo"<img src=\"css/$cssname/images/firstdisabled.gif\" alt=\"Go to first comic\" /> <img src=\"css/$cssname/images/backdisabled.gif\" alt=\"Go back one comic\" />";
	
}

//Archive dropdownbox
echo"<select name=\"archive\" onchange=\"location.href=this.options[selectedIndex].value\">
<option value=\"\" selected=\"selected\">- Browse the Archive -</option>
";
//Get episodes for database and order them by Episodenr
$sqlQuery = "SELECT * FROM " . $prefix . "comic ORDER BY episodenr DESC";
$sqlResult = @mysql_query ($sqlQuery);
	
//print all episodes
$i = 0;
while ($sqlRowsLatest = @mysql_fetch_array ($sqlResult)) {
		echo"<option value=\"?epi=" . $sqlRowsLatest['0'] . "\">";
		if ($sqlRowsLatest['0'] < 100) {
			echo"0";
			if ($sqlRowsLatest['0'] < 10) {
				echo"0";
			}
		}
		echo $sqlRowsLatest['0'] . ": " . $sqlRowsLatest['2'] . "</option>";
}

echo"</select>";
if ($epi != $latestEpisode['0'] && $epi) {

	echo"<a href=\"?epi=" . ($epi + 1) . "\"><img src=\"css/$cssname/images/next.gif\" alt=\"Go to next comic\" /></a> ";
	echo"<a href=\"?epi=" . $latestEpisode['0'] . "\"><img src=\"css/$cssname/images/latest.gif\" alt=\"Go to the latest comic\" /></a> ";
	
} else {
	
	echo"<img src=\"css/$cssname/images/nextdisabled.gif\" alt=\"Go to next comic\" /> <img src=\"css/$cssname/images/latestdisabled.gif\" alt=\"Go to the latest comic\" />";
	
}
echo"</div>";
?>