<?php
//Fill in your prefix
$prefix = "";

//Database location (localhost):
$location = "";

//Username:
$username = "";

//Password:
$password = "";

//Database name:
$dbname = "";



//Do not change this
mysql_connect($location,$username,$password);
mysql_select_db($dbname);
?>