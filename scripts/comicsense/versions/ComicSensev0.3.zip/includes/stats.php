<?php
	include('includes/connect.php');
	
	if (!$_GET['comments']) {
		$sqlQuery = "SELECT * FROM " . $prefix . "stats WHERE episodenr =" . $currentEpi['0']  . " AND ip='" . $_SERVER['REMOTE_ADDR'] . "'";
		$sqlResult = @mysql_query ($sqlQuery);
		
		$firstView = true;
		
		while ($sqlRowsIp = @mysql_fetch_array ($sqlResult)) {
			$count = $sqlRowsIp['2'] + 1;
			$query="UPDATE " . $prefix . "stats SET `count` = '$count' WHERE `episodenr` = " . $currentEpi['0'] . " AND CONVERT(`ip` USING utf8) = '" . $_SERVER['REMOTE_ADDR'] . "' LIMIT 1";
			mysql_query($query);
			$firstView = false;
		}
		
		if ($firstView){
			$query="INSERT INTO " . $prefix . "stats (episodenr, ip, count) VALUES ('" . $currentEpi['0'] . "', '" . $_SERVER['REMOTE_ADDR'] . "', '1')";
			mysql_query($query);
		}
	}
	
	$sqlQuery = "SELECT * FROM " . $prefix . "stats WHERE episodenr =" . $currentEpi['0']  . "";
	$sqlResult = @mysql_query ($sqlQuery);
	
	$total = 0;
	while ($sqlRowsCount = @mysql_fetch_array ($sqlResult)) {
		$total = $total + $sqlRowsCount['2'];
	}
	
	$sqlQuery = "SELECT COUNT(*) FROM " . $prefix . "stats WHERE episodenr =" . $currentEpi['0']  . "";
	$sqlResult = @mysql_query ($sqlQuery);
	
	$ips = 0;
	while ($sqlIpCount = @mysql_fetch_array ($sqlResult)) {
		$ips = $sqlIpCount['0'];
	}
	
	if ($currentEpi['0'] > 0){
		echo"<div class=\"stats\">$ips different persons a total of $total times</div>";
	} else {
		echo"<div class=\"stats\">$ips people have loaded this page a total of $total times</div>";
	}
?>