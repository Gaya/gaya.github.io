<?php
//Process information in session
session_start(); 
header("Cache-control: private"); //IE 6 Fix 

include('includes/header.php');

echo"<div class=\"pageheader\">Create an Admin account:</div>";

include('includes/logincheck.php');
if ($_SESSION['loggedin']) {
	
	if($_POST['post'] && $_POST['username1'] && $_POST['password1'] && $_POST['email1']){
		
		//post to the database!
		include '../includes/connect.php';
		$query="INSERT INTO " . $prefix . "users (username, password, email) VALUES ('" . $_POST['username1'] . "', '" . md5($_POST['password1']) . "', '" . $_POST['email1'] . "')";
	mysql_query($query);
		echo"<div class=\"message\">The user has been added to the database!</div>
	<div class=\"smallermessage\">You will be redirected account creation page, if not so... please click <a href=\"" .  $_SERVER['PHP_SELF'] . "\">this</a> url.</div>
	<script language=\"JavaScript\"><!--
	setTimeout('Redirect()',2000);
	function Redirect()
	{
		location.href = '" .  $_SERVER['PHP_SELF'] . "';
	}
	// --></script>";
		
	} else {	
		echo"
		<form method=\"post\" action=\"" .  $_SERVER['PHP_SELF'] . "\">
			<div class=\"commentform\">
				<input type=\"hidden\" name=\"post\" value=\"true\" />
				Enter informatie to process into the database:<br />";
			
			if ($_POST['post'] && !$_POST['username1']) {
				echo"<div class=\"error\">Please make sure you enter a username</div>";
			}
			
			if ($_POST['post'] && !$_POST['password1']) {
				echo"<div class=\"error\">Set a password</div>";
			}
			
			if ($_POST['post'] && !$_POST['email1']) {
				echo"<div class=\"error\">Enter the user's e-mail address</div>";
			}
				
			echo"<table>
					<tr>
						<td>Username:</td><td><input type=\"text\" style=\"width: 200px;\" class=\"inputform\" value=\"" . $_POST['username1'] . "\" name=\"username1\" size=\"20\" />
						</td>
					</tr>
					<tr>
						<td>Password:</td><td><input type=\"password\" style=\"width: 200px;\" class=\"inputform\" value=\"" . $_POST['password1'] . "\" name=\"password1\" size=\"20\" /> (will be hashed in md5)</td>
					</tr>
					<tr>
						<td>E-mail address:</td><td><input type=\"text\" style=\"width: 200px;\" class=\"inputform\" value=\"" . $_POST['email1'] . "\" name=\"email1\" size=\"20\" /></td>
					</tr>
					<tr>
						<td colspan=\"2\" class=\"buttoncell\">
							<input type=\"submit\" class=\"button\" value=\"Create User\" />
						</td>
					</tr>
				</table>
			</div>
		</form>
		";
	}
}

include('includes/footer.php');
	
?>