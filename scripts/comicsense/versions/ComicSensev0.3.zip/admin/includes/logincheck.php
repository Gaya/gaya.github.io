<?php
if ($_SESSION['loggedin'] && $_GET['destroy']) {
	$_SESSION['loggedin'] = '';
}

$auth = $_POST['auth'];

//check after pressing login
if ($auth && $_POST['username']) {
	include '../includes/connect.php';
			
	$sqlQuery = "SELECT * FROM " . $prefix . "users WHERE username = '" . $_POST['username'] . "'";
	$sqlResult = @mysql_query ($sqlQuery);
	while ($sqlRowsUsername = @mysql_fetch_array ($sqlResult)) {
		if($sqlRowsUsername['1'] == md5($_POST['password'])) {
			$_SESSION['username'] = $sqlRowsUsername['0'];
			$_SESSION['loggedin'] = true;
		} else {
			$failed = true;
			$excists = true;
		}
	}
}

if (!$_SESSION['loggedin']) {
	
	echo"
	<form method=\"post\" action=\"" . $_SERVER['PHP_SELF'] . "\">
	<div>
		";
		if ($failed && $auth) {
			echo"<div class=\"error\">Wrong password.</div>";
		}
		if (!$excists && $auth && $_POST['username']) {
			echo"<div class=\"error\">User not found.</div>";
		}
	echo"
		<input type=\"hidden\" name=\"auth\" value=\"yes\" />
		<table>
			<tr>
				<td>
					Username:
				</td>
				<td>
					<input type=\"text\" style=\"width: 150px;\" class=\"inputform\" name=\"username\" value=\"" . $_POST['username'] . "\" />
						</td>";
			if($auth && !$_POST['username']){
				echo"<td><div class=\"error\">Username required!</div></td>";
			}
			echo"
					</tr>
					<tr>
						<td>
							Password:
						</td>
						<td>
							<input class=\"inputform\" style=\"width: 150px;\" value=\"" . $_POST['password'] . "\" type=\"password\" name=\"password\" />
						</td>";
			if($auth && !$_POST['password']){
				echo"<td><div class=\"error\">Password required!</div></td>";
			}
echo"		</tr>
			<tr>
				<td class=\"buttoncell\" colspan=\"2\">
					<input class=\"button\" type=\"submit\" value=\"login\" />
				</td>
			</tr>
		</table>
	</div>
	</form>";

} else {
	echo"<div class=\"loggedin\">Logged in as: " . $_SESSION['username'] . " | <a href=\"" . $_SERVER['PHP_SELF'] . "?destroy=true\">log out</a></div>";
}
?>