<?php
//Process information in session
session_start(); 
header("Cache-control: private"); //IE 6 Fix 

include('includes/header.php');

$currentEpi['0'] = -4;

echo"<div class=\"pageheader\">Public Announcements:</div>";

include 'includes/connect.php';

//select all pa's
$sqlQuery = "SELECT * FROM " . $prefix . "pa ORDER BY panr DESC";
$sqlResult = @mysql_query ($sqlQuery);

$i = 0;
while ($sqlPa = @mysql_fetch_array ($sqlResult)) {
	$i++;
	echo"<div class=\"pabox\">
		<div class=\"paname\">
		" . $sqlPa['2'] . ":
		</div>
		<div class=\"patype\">
		Type: " . $sqlPa['3'] . " | By: " . $sqlPa['4'] . "
		</div>
		<div class=\"pacontent\">" . $sqlPa['5'] . "</div>
		<div class=\"padate\">
		Posted on: " . date("d M Y", strtotime($sqlPa['1'])) . " at: " . date("H:i", strtotime($sqlPa['1'])) . "
		</div>
	</div>";
}
if ($i == 0) {
	echo"<div class=\"message\">Nothing Posted Yet</div>";
}

include('includes/stats.php');

include('includes/footer.php');
	
?>