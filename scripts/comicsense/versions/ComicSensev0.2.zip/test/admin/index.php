<?php
//Process information in session
session_start(); 
header("Cache-control: private"); //IE 6 Fix 

if ($_SESSION['loggedin'] && $destroy) {
	$_SESSION['loggedin'] = '';
}

include('includes/header.php');

echo"<div class=\"pageheader\">Admin:</div>
<div class=\"pageintro\">
<a href=\"stats.php\">Stats</a><br />
<a href=\"upload.php\">Upload Episode</a><br />
<a href=\"post.php\">Post News</a><br />
<a href=\"create.php\">Create Account</a><br />
</div>
";

include('includes/footer.php');

?>