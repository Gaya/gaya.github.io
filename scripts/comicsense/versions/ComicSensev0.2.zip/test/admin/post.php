<?php
//Process information in session
session_start(); 
header("Cache-control: private"); //IE 6 Fix 

include('includes/header.php');

echo"<div class=\"pageheader\">P.A. Posting:</div>";

include('includes/logincheck.php');
if ($_SESSION['loggedin']) {

	if ($_POST['post'] && $_POST['title'] && $_POST['type'] && $_POST['message']) {
	
	//post to the database!
	include '../includes/connect.php';
	
	//prevent html + insert linebreaks
	$fldtextArea_name = htmlspecialchars($_POST['message'], ENT_QUOTES);
	$fldtextArea_name = str_replace("\n", "<br />" , $fldtextArea_name);
	
	$query="INSERT INTO " . $prefix . "pa (panr, date, title, name, type, message) VALUES ('', NOW(), '" . $_POST['title'] . "', '" . $_SESSION['username'] . "', '" . $_POST['type'] . "', '$fldtextArea_name')";
	mysql_query($query);
	
	echo"<div class=\"message\">Your message has been posted!</div>
	<div class=\"smallermessage\">You will be redirected to the posting page, if not so... please click <a href=\"" . $PHP_SELF . "\">this</a> url.</div>
	<script language=\"JavaScript\"><!--
	setTimeout('Redirect()',2000);
	function Redirect()
	{
		location.href = '" . $PHP_SELF . "';
	}
	// --></script>
	";
	
	} else {
	
	echo"<form method=\"post\" action=\"" . $PHP_SELF . "\">
			<div class=\"commentform\">
			<input type=\"hidden\" name=\"post\" value=\"true\" />
			Fill in the stuff you want to post to the PA:<br />
		";
		
		if ($_POST['post'] && !$_POST['title']) {
			echo"<div class=\"error\">Please make sure you enter a title</div>";
		}
		
		if ($_POST['post'] && !$_POST['type']) {
			echo"<div class=\"error\">Select a type please</div>";
		}
		
		if ($_POST['post'] && !$_POST['message']) {
			echo"<div class=\"error\">Enter your post</div>";
		}

		
		echo"
			<table>
				<tr>
					<td>Title:</td><td><input type=\"text\" class=\"inputform\" value=\"" . $_POST['title'] . "\" name=\"title\" size=\"20\" />
					</td>
				</tr>
				<tr>
					<td>Type:</td>
					<td>
					<select name=\"type\" style=\"inputform\">
						<option value=\"\">Choose the type of post</option>
						<option value=\"\">-----------------------------------</option>
						<option value=\"Announcement\"";
						if ($_POST['type'] == 'Announcement') { echo" selected"; }
						echo">Announcement</option>
						<option value=\"Update\"";
						if ($_POST['type'] == 'Update') { echo" selected"; }
						echo">Update</option>
						<option value=\"Blog\"";
						if ($_POST['type'] == 'Blog') { echo" selected"; }
						echo">Blog</option>
					</select>
					</td>
				</tr>
				<tr>
					<td class=\"commentcell\">Message:</td><td><textarea cols=\"10\" class=\"inputform\" rows=\"4\" name=\"message\">" . $_POST['message'] . "</textarea></td>
				</tr>
				<tr>
					<td colspan=\"2\" class=\"buttoncell\">
						<input type=\"submit\" class=\"button\" value=\"Post Entry\" />
					</td>
				</tr>
			</table>
			</div>
		</form>
		";
	}
	
}

include('includes/footer.php');
	
?>