<?php
//Process information in session
session_start(); 
header("Cache-control: private"); //IE 6 Fix 

include('includes/header.php');

$currentEpi['0'] = -1;

echo"<div class=\"pageheader\">Archive:</div>
<div class=\"pageintro\">Write something about the archive here.</div>";

//Connect to the database
include('includes/connect.php');

//Get ALL the information on comics
$sqlQuery = "SELECT * FROM " . $prefix . "comic ORDER BY date DESC";
$sqlResult = @mysql_query ($sqlQuery);

//initialize variables
$yearStore = array();
while ($sqlRowsArchive = @mysql_fetch_array ($sqlResult)) {
	$year = date("Y", strtotime($sqlRowsArchive['1']));
	
	if (!in_array ($year, $yearStore)){
		echo"<div class=\"archiveyear\">" . $year . "</div>";
		
		array_push($yearStore, $year);
		
		$sqlQuery = "SELECT * FROM " . $prefix . "comic WHERE YEAR(date) = $year ORDER BY date DESC";
		$sqlResult2 = @mysql_query ($sqlQuery);
		
		echo"<div class=\"rowprint\">";
		while ($sqlRowsYear = @mysql_fetch_array ($sqlResult2)) {
			echo date("d M Y", strtotime($sqlRowsYear['1'])) . " | <a href=\"index.php?epi=" . $sqlRowsYear['0'] . "\">#" . $sqlRowsYear['0'] . ": " . $sqlRowsYear['2'] . "</a><br />";
		}
		echo"</div>";
	}
}
	
include('includes/stats.php');

include('includes/footer.php');
	
?>