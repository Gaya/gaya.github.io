<?php
//Process information in session
session_start(); 
header("Cache-control: private"); //IE 6 Fix 

include('includes/header.php');

if ($_POST['post'] && $_POST['name'] && $_POST['comment'] && !$insert)  {
		
	include('includes/postcomment.php');	

} else {
	
//Connect to the database
include('includes/connect.php');

//select the latest episodenr
$sqlQuery = "SELECT * FROM " . $prefix . "comic";
$sqlResult = @mysql_query ($sqlQuery);
	
//check all episodenumbers
$i = 0;
while ($sqlRowsLatest = @mysql_fetch_array ($sqlResult)) {
	if($sqlRowsLatest[0] > $i) {
		$i = $sqlRowsLatest[0];
		$latestEpisode = $sqlRowsLatest;
	}
}

if ($epi) {
	//get the gequested episode
	$sqlQuery = "SELECT * FROM " . $prefix . "comic WHERE episodenr = $epi";
	$sqlResult = @mysql_query ($sqlQuery);
	
	//put info an array
	while ($sqlRowsRequest = @mysql_fetch_array ($sqlResult)) {
		$currentEpi = $sqlRowsRequest;
	}
} else {
	$currentEpi = $latestEpisode;
}

include('includes/buttons.php');

echo"<div class=\"comic\"><img src=\"episodes/" . $currentEpi['0'] . ".jpg\" alt=\"#" . $currentEpi['0'] . ": " . $currentEpi['2'] . "\" /></div>";

include('includes/buttons.php');

include('includes/stats.php');

//post date
echo"<div class=\"commentbar\">
	<div class=\"date\">This comic has been here since: " . date("d M Y", strtotime($currentEpi['1'])) . "</div>";

	include('includes/comments.php');
	
}

include('includes/footer.php');
	
?>