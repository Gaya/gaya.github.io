<?php
		//exclude html features
		$fldtextArea_name = htmlspecialchars($_POST['comment'], ENT_QUOTES);
		$fldtextArea_name = str_replace("\n", "<br />" , $fldtextArea_name);
		//place in database
		include('includes/connect.php');
		
		//filter input for hacks and html
		$name = htmlspecialchars($_POST['name'], ENT_QUOTES);
		$email = htmlspecialchars($_POST['email'], ENT_QUOTES);
		$website = htmlspecialchars($_POST['website'], ENT_QUOTES);
				
		$query="INSERT INTO " . $prefix . "comments (episodenr, commentnr, name, email, website, comment, ip, date) VALUES ('$epi', '', '$name', '$email', '$website', '$fldtextArea_name', '" . $_SERVER['REMOTE_ADDR'] . "', NOW() )";
		mysql_query($query);
		
		echo"<div class=\"message\">Your comment has been posted!</div>
		<div class=\"smallermessage\">You will be redirected to episode #$epi, if not so... please click <a href=\"?epi=$epi&comments=true&insert=true#comments\">this</a> url.</div>
		<script language=\"JavaScript\"><!--
		setTimeout('Redirect()',2000);
		function Redirect()
		{
			location.href = '?epi=$epi&comments=true&insert=true#comments';
		}
		// --></script>
		";
?>