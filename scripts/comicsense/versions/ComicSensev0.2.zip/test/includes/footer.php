			</div>
			<div class="footer">
				<a href="http://www.gayadesign.nl/comicsense/">Comic Sense Beta // &copy; 2006 // By Gaya<a/><br />
				
				<a href="http://validator.w3.org/check?uri=referer"><img src="images/xhtml.gif" alt="xhtml 1.0 strict valid" /></a>
				<a href="http://jigsaw.w3.org/css-validator/validator?uri=http%3A%2F%2Fwww.gayadesign.nl%2Flookingforexp%2Fcss%2F<?php echo $cssname ?>%2Fstylesheet.css&amp;warning=no&amp;profile=css2&amp;usermedium=all"><img src="images/css.gif" alt="css 2.0 valid" /></a>
				<a href="http://getfirefox.com/"><img src="images/firefox.png" alt="works in firefox" /></a>
			</div>
			
		</div>

	</body>
</html>