<?php
//get number of comments on this comic
$sqlQuery = "SELECT COUNT(*) FROM " . $prefix . "comments WHERE episodenr = " .$currentEpi['0'];
$sqlResult = @mysql_query ($sqlQuery);

//print the number
while ($sqlCommentsNumber = @mysql_fetch_array ($sqlResult)) {
	if ($sqlCommentsNumber['0'] > 0){
		echo $sqlCommentsNumber['0'] . " Comments Posted";
	} else {
		echo"No comments yet";
	}
}

//open the comment bar
if ($comments) {
echo" |<a class=\"commentslink\" name=\"comments\">&nbsp;</a><a href=\"?epi=" . $currentEpi['0'] . "\">Close comments</a>";
} else {
echo" |<a class=\"commentslink\" name=\"comments\">&nbsp;</a><a href=\"?epi=" . $currentEpi['0'] . "&amp;comments=true#comments\">Read / Place comments</a>";
}

if ($comments) {
	
	//select all comments
	$sqlQuery = "SELECT * FROM " . $prefix . "comments WHERE episodenr = " . $currentEpi['0'] . " ORDER BY commentnr";
	$sqlResult = @mysql_query ($sqlQuery);

	while ($sqlComments = @mysql_fetch_array ($sqlResult)) {
		echo"<div class=\"commentbox\">
			<div class=\"commentname\">
			<a href=\"http://" . $sqlComments['4'] . "\">" . $sqlComments['2'] . "</a> said:
			</div>
			<div class=\"commentcontent\">" . $sqlComments['5'] . "</div>
			<div class=\"commentdate\">
			Comment posted on: " . date("d M Y", strtotime($sqlComments['7'])) . " at: " . date("H:i", strtotime($sqlComments['7'])) . " | <a href=\"mailto:" . $sqlComments['3'] . "\">/whisper [" . $sqlComments['2'] . "]</a>
			</div>
		</div>";
	}
	
	echo"
	<form method=\"post\" action=\"" . $PHP_SELF . "?epi=" . $currentEpi['0'] . "&amp;comments=true#commentform\">
		<div class=\"commentform\">
		<a name=\"commentform\"><input type=\"hidden\" name=\"post\" value=\"true\" /></a>
		Give your comment on this comic (or on us, or whatever):<br />
	";
	
	if ($_POST['post'] && !$_POST['name']) {
		echo"<div class=\"error\">Enter your name, please T_T</div>";
	}
	
	if ($_POST['post'] && !$_POST['comment']) {
		echo"<div class=\"error\">If you want to comment, enter something~ ^^'</div>";
	}
	
	echo"
		<table>
			<tr>
				<td>Name:</td><td><input type=\"text\" class=\"inputform\" value=\"" . $_POST['name'] . "\" name=\"name\" size=\"20\" />
				</td>
			</tr>
			<tr>
				<td>E-mail:</td><td><input type=\"text\" class=\"inputform\" value=\"" . $_POST['email'] . "\" name=\"email\" size=\"20\" /></td>
			</tr>
			<tr>
				<td>Website:</td><td><input type=\"text\" class=\"inputform\" value=\"" . $_POST['website'] . "\" name=\"website\" size=\"20\" /> (No http://)</td>
			</tr>
			<tr>
				<td class=\"commentcell\">Comment:</td><td><textarea cols=\"10\" class=\"inputform\" rows=\"4\" name=\"comment\">" . $_POST['comment'] . "</textarea></td>
			</tr>
			<tr>
				<td colspan=\"2\" class=\"buttoncell\">
					<input type=\"submit\" class=\"button\" value=\"Save Game!\" />
				</td>
			</tr>
		</table>
		</div>
	</form>
	";
}
	echo"</div>";
?>