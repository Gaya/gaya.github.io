<?php
//Process information in session
session_start(); 
header("Cache-control: private"); //IE 6 Fix 

include('includes/header.php');

echo"<div class=\"pageheader\">Stats:</div>";

include('includes/logincheck.php');
if ($_SESSION['loggedin']) {
	
	echo"<table>";
	
	include '../includes/connect.php';
	
	$sqlQuery2 = "SELECT * FROM " . $prefix . "stats GROUP BY episodenr";
	$sqlResult2 = @mysql_query ($sqlQuery2);
	
	while ($sqlRowsCount2 = @mysql_fetch_array ($sqlResult2)) {
		
		$sqlQuery = "SELECT * FROM " . $prefix . "stats WHERE episodenr =" . $sqlRowsCount2['0']  . "";
		$sqlResult3 = @mysql_query ($sqlQuery);
		
		$total = 0;
		while ($sqlRowsCount = @mysql_fetch_array ($sqlResult3)) {
			$total = $total + $sqlRowsCount['2'];
		}
		
		$sqlQuery = "SELECT COUNT(*) FROM " . $prefix . "stats WHERE episodenr =" . $sqlRowsCount2['0']  . "";
		$sqlResult = @mysql_query ($sqlQuery);
		
		$ips = 0;
		while ($sqlIpCount = @mysql_fetch_array ($sqlResult)) {
			$ips = $sqlIpCount['0'];
		}
		
		echo"<tr><td style=\"text-align: right;\">";
		if ($sqlRowsCount2['0'] == -4) {
			echo"Public Announcements:</td><td>$ips people / $total times</td>";
		} else if ($sqlRowsCount2['0'] == -3) {
			echo"Support Us:</td><td>$ips people / $total times</td>";
		} else if($sqlRowsCount2['0'] == -2) {
			echo"About:</td><td>$ips people / $total times</td>";
		} else if($sqlRowsCount2['0'] == -1){
			echo"Archive:</td><td>$ips people / $total times</td>";
		} else {
			echo"Episode #" . $sqlRowsCount2['0'] . ":</td><td>$ips people / $total times</td>";
		}
		echo"</tr>";

	}
	
	echo"</table>";
}

include('includes/footer.php');
	
?>