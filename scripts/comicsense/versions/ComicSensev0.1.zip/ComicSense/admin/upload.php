<?php
//Process information in session
session_start(); 
header("Cache-control: private"); //IE 6 Fix 

include('includes/header.php');
?>

<div class="pageheader">Upload Episode</div>

<?
include('includes/logincheck.php');
if ($_SESSION['loggedin']) {

	$status = $_GET['upload'];
	$filetype = $_FILES['file']['type'];
	if  ($status=='1' && $filetype == "image/jpeg") {
		$form_password = $_POST['password'];

		$upload_folder = '../episodes/';

		copy("$file","$upload_folder$file_name");
		
		include('../includes/connect.php');
		
		//select the latest episodenr
		$sqlQuery = "SELECT * FROM " . $prefix . "comic";
		$sqlResult = @mysql_query ($sqlQuery);
			
		//check all episodenumbers
		$i = 0;
		while ($sqlRowsLatest = @mysql_fetch_array ($sqlResult)) {
			if($sqlRowsLatest[0] > $i) {
				$i = $sqlRowsLatest[0];
				$latestEpisode = $sqlRowsLatest;
			}
		}
		
		$query="INSERT INTO " . $prefix . "comic (episodenr, date, title) VALUES ('" . ($latestEpisode['0']+1) . "', NOW( ) , '" . $_POST['title'] . "')";
		mysql_query($query);
		
		rename("$upload_folder$file_name", "$upload_folder" . ($latestEpisode['0']+1) . ".jpg");
		
		echo "<center><div class='norm'><b>$file_name was successfully uploaded.</b></div></center>";

	} else {
	?>
	<form action="<? $self_file = $_SERVER['PHP_SELF']; echo "$self_file"; ?>?upload=1" method="post" enctype="multipart/form-data" name="form1">
	<table align="center">
	  <tr>
	    <td>File to upload:</td>
	    <td><input name="file" type="file" /></td>
	  </tr>
	   <tr>
	    <td>Title:</td>
	    <td><input name="title" type="text" /></td>
	  </tr>
	  <tr>
	    <td colspan=2 style="text-align: center;"><input type="submit" name="Submit" value="Upload" class="button" /></td>
	  </tr>
	</table>

	</form>
<?
	}
}

include('includes/footer.php');

?>