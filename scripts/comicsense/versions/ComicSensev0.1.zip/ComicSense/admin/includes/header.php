<?php $cssname = "standard"; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
	<head>
		<title>ComicSense - Making sense in online comics</title>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
		<link href="../css/<?php echo $cssname; ?>/stylesheet.css" rel="stylesheet" type="text/css" />
	</head>
	
	<body>
		<div class="container">
		
			<div class="main">
				<div class="header">
					<div class="banner">
						ADMIN!
					</div>
				</div>
				
				<div class="menu">
					<a href="../index.php">main</a><a href="../pa.php">news</a><a href="../archive.php">archive</a><a href="index.php">admin</a>
				</div>
				<div class="adminmenu">
					Admin Menu:<br />
					<a href="stats.php">stats</a>
					<a href="upload.php">upload</a>
					<a href="post.php">post</a>
					<a href="create.php">create</a>
				</div>