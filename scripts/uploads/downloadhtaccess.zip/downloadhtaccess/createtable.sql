CREATE TABLE `download` (
	`filename` varchar(255) NOT NULL,
	`stats` int(11) NOT NULL,
	PRIMARY KEY  (`filename`)
)