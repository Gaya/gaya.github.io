<?php
	/*******************************************************************
	//                     Creator: Gaya Kessler                      //
	//                     Company: Cybox.nl                          //
	//                     Scriptname: HotSense Delay                 //
	//                     Version: 0.1                               //
	//                     Release date: July 12th 2007               //
	*******************************************************************/

	include('config.php');
	
	$query  = "SELECT site, referer, hotlinked, NOW() AS date FROM imagecheck;";
	$sql	= mysql_query($query);
	
	echo "
	<html>
		<head>
			<title>Hotsense - referer checker</title>
		</head>
		
		<body>
			<h1>HotSense - Referer Checker</h1>
	";
	
	if (mysql_num_rows($sql) >= 1) {
		echo "
		<table border='1' cellspacing='4'>
			<tr>
				<td>website:</td>
				<td>referer:</td>
				<td>hotlinked at:</td>
				<td>image blocked:</td>
				<td>time left:</td>
			</tr>
		";
	
		for ($i = 0; $i < mysql_num_rows($sql); $i++) {
			$data 	= mysql_fetch_object($sql);
			
			// get time of first linked
			$hotlinked_hour = date("G", strtotime($data->hotlinked));
			$hotlinked_minutes = date("i", strtotime($data->hotlinked));
			
			//get current database time
			$date_hour = date("G", strtotime($data->date));
			$date_minutes = date("i", strtotime($data->date));
			
			// check if time is over
			if ((($hotlinked_hour + $delay_hours) >= $date_hour) &&  (($hotlinked_minutes + $delay_minutes) >= $date_minutes)) {
				$block = 'no';
				$timeleft_hours = $hotlinked_hour - ($date_hour - $delay_hours);
				$timeleft_minutes = $hotlinked_minutes - ($date_minutes - $delay_minutes);
			} else {
				$block = 'yes';
				$timeleft_hours = 0;
				$timeleft_minutes = 0;
			}
			
			echo "
			<tr>
				<td>
					" . $data->site . "
				</td>
				<td>
					" . $data->referer . "
				</td>
				<td>
					" . $data->hotlinked . "
				</td>
				<td>
					" . $block . "
				</td>
				<td>
					" . $timeleft_hours . ":" . $timeleft_minutes . "
				</td>
			</tr>
			";
		}
		
		echo "
		</table>
		";
	} else {
		echo "no hotlinked images yet.";
	}
	
	echo "
			<br /><br />HotSense is created by <a href='http://www.gayadesign.nl'>gaya kessler</a>
		</body>
	</html>
	";
?>