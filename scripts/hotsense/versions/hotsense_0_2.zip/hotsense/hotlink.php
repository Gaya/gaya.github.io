<?php
	/*******************************************************************
	//                     Creator: Gaya Kessler                      //
	//                     Company: Cybox.nl                          //
	//                     Scriptname: HotSense Delay                 //
	//                     Version: 0.2                               //
	//                     Release date: July 13th 2007               //
	*******************************************************************/

	include('config.php');
	
	// Important information that is generated
	$referer 		= $_SERVER['HTTP_REFERER'];			// the hotlinking site
	$site 			= $_GET['site'];					// site from which the hotlink is atempted
	$requested		= $_GET['img'];						// the requested image
	$date			= "NOW()";							// this will be the database's date
	
	/*******************************************************************
	//       Here comes the core                                      //
	*******************************************************************/
	
	//Trying to hyjack your own site? haha, no way!
	if ($referer == $site) {
		$file = $site . $requested;
	} else {
		// Referer is different from the site which it came from
		// let's see if this referer has linked you before
		$query  = "SELECT site, referer, hotlinked, NOW() AS date FROM imagecheck WHERE site = '" . $_GET['site'] . "' AND referer = '" . $referer . "';";
		$sql	= mysql_query($query);
		
		if (mysql_num_rows($sql) >= 1) {
			
			for ($i = 0; $i < mysql_num_rows($sql); $i++) {
				$data 	= mysql_fetch_object($sql);
				
				// get time of first linked
				$hotlinked_hour = date("G", strtotime($data->hotlinked));
				$hotlinked_minutes = date("i", strtotime($data->hotlinked));
				$hotlinked_day = date("d", strtotime($data->hotlinked));
				$hotlinked_month = date("m", strtotime($data->hotlinked));
				$hotlinked_year = date("Y", strtotime($data->hotlinked));
				
				//get current database time
				$date_hour = date("G", strtotime($data->date));
				$date_minutes = date("i", strtotime($data->date));
				$date_day = date("d", strtotime($data->date));
				$date_month = date("m", strtotime($data->date));
				$date_year = date("Y", strtotime($data->date));
				
				// Has this request been placed today?
				if (($date_day == $hotlinked_day) && ($date_month == $hotlinked_month) && ($date_year == $hotlinked_year)) {
					// check if time of this day is over
					if ((($hotlinked_hour + $delay_hours) >= $date_hour) &&  (($hotlinked_minutes + $delay_minutes) >= $date_minutes)) {
						// time is not over yet, give the original
						$file = $site . $requested;
					} else {
						// Time of today is over!
						$file = $stolen;
					}
				} else {
					// Day is over, so block image.
					$file = $stolen;
				}
			}
			
		} else {
		
			// the referer does not appear in the database so lets add it!
			$insertquery  = "INSERT INTO `imagecheck` ( `site` , `referer` , `hotlinked` ) VALUES ('" . $site . "', '" . $referer . "', " . $date . ");";
			$insertsql	= mysql_query($insertquery);
			
			// we'll set the image back to the original
			$file = $site . $requested;
			
		}
		
	}
	
	// let's the users their image!
	header('Content-type: image/jpeg');
	readfile($file);
	
	// close the database connection
	mysql_close();
?>