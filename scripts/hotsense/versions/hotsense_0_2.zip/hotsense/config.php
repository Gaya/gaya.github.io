<?
// SQL connection:
$db_location 	= "localhost";												//location of the db host (localhost)
$db_username 	= "username";												//username
$db_password 	= "password";												//password
$db_dbname 		= "databasename";											//database name

//make the database connection
mysql_connect($db_location, $db_username, $db_password)
or die ("Sorry, can't connect to database.");								// couldn't connect
mysql_select_db($db_dbname);

$stolen					= "http://yourdomain.com/hotsense/hotlink.jpg";		// The image shown when hotlink time is over! (include http:// if external)
$delay_hours			= 0;												// The amount of hours to delay (in hours, default: 0)
$delay_minutes			= 15;												// The amount of minutes to delay (in minutes, default: 15)
?>