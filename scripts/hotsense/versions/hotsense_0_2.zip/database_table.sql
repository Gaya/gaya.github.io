CREATE TABLE `imagecheck` (
  `site` varchar(255) NOT NULL default '',
  `referer` varchar(255) NOT NULL default '',
  `hotlinked` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`site`,`referer`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;